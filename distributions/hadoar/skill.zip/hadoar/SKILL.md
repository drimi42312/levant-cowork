---
name: hadoar
description: Prepare Hebrew presale emails for HaDoar 8 (הדואר 8, יפו) from the bundled approved template and prospect/apartment details. Use for /hadoar, project introductions, specific apartment offers, and requested WhatsApp or apartment-combination variants.
metadata:
  display_name: HaDoar 8
---

# HaDoar 8

Prepare a polished Hebrew presale email for the HaDoar 8 project. Accept `/hadoar` as an invocation cue. The host controls installation and slash-command discovery; this package does not register a command by itself.

## Reference and scope

Read [the complete original marketing template](references/presale-template.md) before each production. It is the core wording and project reference, updated with Dan's approved clarifications of 2026-10-05. Apply the conflict resolutions below before copying examples. Do not mix other projects into the result.

This portable skill defaults to producing the email in chat and an HTML file when file creation is available. Use supplied prospect details, conversation context, uploaded/current price data, and supplied attachment files. Do not require the original local filesystem path or installed connectors. The source describes Gmail drafting and Fireberry updates; these are optional execution steps only when requested and available, not prerequisites to writing. Never send an email or WhatsApp message. Never claim a draft, CRM update, upload, or attachment was completed without performing and verifying it.

## Gather the necessary inputs

Identify the recipient name, sender (Dan by default; Lovi when specified), recipient type, whether a conversation occurred, desired output channel, budget/rooms, and any requested apartments or combinations. An email address is needed only for a mailbox draft, not for writing the email. Do not infer recipient gender solely from a name; use neutral phrasing where possible.

For apartment offers, obtain the current presale price, availability, apartment number, floor, model, rooms, AREA, BALCONY, STREET/GARDEN, and PARKING as applicable. Prefer the current supplied workbook; user-confirmed current details may supply the relevant rows. To claim a project-wide or room-group minimum, require complete available inventory for that scope or an explicitly confirmed minimum, not just one selected apartment.

When local price files are provided, choose the newest applicable `.xlsx` by modification time, ignoring `~$` lock files. If upload metadata cannot establish recency, ask which workbook is current. Use the presale PRICE column, not the other PRICE column. Missing presale price means unavailable; free-text historical comments do not establish availability. Use ROOMS and PARKING for each apartment, not assumptions based on model or facing. Treat historical prices, availability, delivery timing, construction stage, four-unit promotion, in the reference as dated claims requiring current confirmation. Do not blindly reuse them.

Ask one concise, grouped question before producing a final email when required facts, attachment choices, or reference conflicts remain unresolved. Do not invent missing data. If the user explicitly wants a partial draft, label it incomplete and keep unresolved facts in clear placeholders; never present it as ready to send.

## Choose and compose the variant

- Default: email. A bare `/hadoar` should prompt for the recipient/context and current data needed. If context is only a just-ended phone call and the channel is unclear, ask email or WhatsApp.
- New lead / introduction / no previous call: use section 3.2. Use the opening `תודה שפנית אלינו לפרויקט הדואר. עד שנחזור אליך טלפונית, אני מצרף כאן נתונים וחומרים על הפרויקט.` and closing `אשמח לתאם שיחה טלפונית או פגישה כדי להציג את הפרויקט והדירות הרלוונטיות.`, with one confirmed minimum-price line per available room group. No model names, areas, facing, specific apartment blocks, or combination pitch. Missing budget/room preferences normally routes here, unless the user explicitly requests particular apartments.
- Following a call or a targeted offer: use section 3.1's fixed project paragraphs and section 3's specific-apartment format as applicable. Keep the approved wording except for factual updates confirmed by the user, sender grammar, and the resolutions below. Do not claim a call occurred without evidence. Order room groups ascending. A mixed-room model such as PATIO B requires a specific-apartment block.
- Combinations: follow section 6, recalculate areas and prices from current component rows, with no fixed 227-square-meter maximum, include all feasibility, approval, cost-exclusion, availability, and inter-floor qualifications. Do not offer 6+7 or 6+16. Historical “possible” combinations are not final engineering approval; never assert vertical adjacency without verified plans.
- WhatsApp only when requested: follow section 4, use literal single-asterisk emphasis and moderate emoji, place the video before the website, retain the presale/availability line, and use `דן, LVNT` for Dan. Adapt sender grammar/signature if Lovi is specified. Do not claim a prior call for a new lead.

## Resolve the source's overlapping rules

1. The explicit 4 October update takes precedence: every marketing email requires `גרסא דיגיטלית הדואר 8_compressed.pdf`, including overview and broker emails. Intro emails otherwise have no plans or price workbook. This supersedes older “no attachments” statements.
2. Dan clarified on 5 October: WhatsApp introductions have no attachments, only video/site links. For non-intro apartment offers, prepare one correct plan per offered model for Dan to send manually.
3. Ordinary email apartment/model blocks show built area + balcony, without total area. Dan confirmed this rule on 5 October; the example now follows it. Combination totals are an exception; WhatsApp may include totals.
4. Email prices are `מחיר: X שח` for a specific apartment and `מחיר: החל מ-X שח` for a model/group. No list-price comparison or discount. Source WhatsApp formats use `💰` and `₪`. Parking costs 400,000 NIS. Removing parking from an apartment requires Dan's prior approval for that apartment before presenting the reduced price. A prospect's request is not approval.
5. GARDEN means `מפנה: עורף`; STREET means `מפנה: חזית`. Never translate GARDEN into “דירת גן”. Include parking only when confirmed.
6. For specific apartments, prefer `תוכניות דירות/HADOAR_APT_<two-digit number>.pdf`; for model offers, use a separate correct plan per mentioned model, including apartment-specific variants when needed. The project marketing brochure is distinct from a combined plans booklet.
7. Explicitly identify the recipient as a broker before applying broker rules. Include the marketing brochure and current price workbook; use separate relevant plans for offered units/models. Attach a complete combined plans file only on explicit request, never automatically because the recipient is a broker.
8. Current price data governs apartment facts over brochure labels. Visually verify apartment number, floor and areas before using a plan. Ask about unresolved mismatches instead of choosing a plan by filename alone.

## Deliver and check

Provide the subject and a clean, readable Hebrew email. Also provide the canonical HTML as a downloadable `.html` file when supported, otherwise an HTML code block. Use `<div dir="rtl" style="font-family:Arial,sans-serif;font-size:14px">`, source bold/underline hierarchy, and direct `<a href>` links. Escape user-supplied values for HTML. The website immediately follows the opening; the video follows the website. For an actual draft/API payload, `body` is the opening plus `(גרסת טקסט - הפירוט המלא בגרסת ה-HTML)` and `htmlBody` contains the full email.

Keep internal notes outside the customer-facing email. State attachment requirements and which files are actually supplied/prepared; do not write “attached” unless they will actually accompany the output/draft. If required files are absent, flag the email as awaiting attachments rather than complete. Provide only the questions when mandatory factual inputs remain unresolved, unless a partial draft was requested.

Before delivery, check the correct variant, approved fixed wording, sender grammar, current data provenance, availability, minima, price format, areas, parking, direct site/video links, and required attachments. Confirm arithmetic for combinations. A text-only preparation does not count as a Gmail draft or CRM update.

If the user requests external execution, use only available authorized tools: create a Gmail draft, never send; check the recipient and correct compose window, attachment names and direct links, and capture the source-required screenshot after attaching. Apply section 8 CRM actions only within the requested scope, using existing customer records where possible and asking for missing follow-up timing rather than inventing it. Report any unavailable integration or unverified attachment check plainly and return the usable email artifact.
